# qt-idi
Interacció i Disseny d'Interfícies (IDI)
