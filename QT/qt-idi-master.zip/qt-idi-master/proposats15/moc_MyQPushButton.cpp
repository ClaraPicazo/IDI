/****************************************************************************
** Meta object code from reading C++ file 'MyQPushButton.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MyQPushButton.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MyQPushButton.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyQPushButton[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   15,   14,   14, 0x0a,
      27,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQPushButton[] = {
    "MyQPushButton\0\0n\0dial(int)\0setRand()\0"
};

void MyQPushButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQPushButton *_t = static_cast<MyQPushButton *>(_o);
        switch (_id) {
        case 0: _t->dial((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->setRand(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQPushButton::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQPushButton::staticMetaObject = {
    { &QPushButton::staticMetaObject, qt_meta_stringdata_MyQPushButton,
      qt_meta_data_MyQPushButton, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQPushButton::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQPushButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQPushButton::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQPushButton))
        return static_cast<void*>(const_cast< MyQPushButton*>(this));
    return QPushButton::qt_metacast(_clname);
}

int MyQPushButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPushButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
